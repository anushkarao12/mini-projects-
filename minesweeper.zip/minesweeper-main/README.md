# Minesweeper 🧠💣

This is an interactive Minesweeper game powered by a custom AI agent that plays the game using logical inference. The AI deduces safe cells and mines based on previous moves and known information — simulating human-like reasoning.

## 🎮 Features
- Interactive GUI using pygame
- Play manually or let the AI play for you
- AI uses logic-based inference to:
  - Identify safe moves
  - Flag mines
- Reset the board or watch the AI finish the game

## 📁 Project Structure
- assets.zip              # Contains image and font assets
- minesweeper.py          # Core game logic and AI
- runner.py               # GUI game loop using pygame
- requirements.txt        # Python dependencies
- README.md               # Project documentation

## 🧠 AI Logic

The AI operates by:

1. Tracking all revealed cells
2. Creating logical sentences based on neighboring mine counts
3. Using inference to:
   - Mark safe cells
   - Identify definite mines
4. Making random moves only when no safe options remain

## 🧪 Requirements

pip install pygame

## 🚀 How to Run

Unzip the assets.zip folder.
Place assets/ in the project directory.
Run the game:
python runner.py

##🕹️ Controls

Left Click on a cell: Reveal the cell
Right Click on a cell: Flag/unflag a cell as a mine
AI Move button: Make a move with the AI
Reset button: Start a new game

## 📸 Screenshots

<img width="743" height="507" alt="image" src="https://github.com/user-attachments/assets/c1c2a509-df19-4c79-b814-8b03d101064e" />
<img width="616" height="437" alt="image" src="https://github.com/user-attachments/assets/0ea6ed01-ac07-41f0-866c-b3e2968c1f58" />
<img width="1124" height="617" alt="image" src="https://github.com/user-attachments/assets/a3e1d833-0442-4e58-bf85-8db33a429e74" />

## 📌 TODOs

- Add difficulty levels (easy/medium/hard)
- Track and display score/timer
- Smarter AI using probability-based inference
