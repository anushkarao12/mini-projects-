import customtkinter as ctk
from tkinter import filedialog, messagebox
from PIL import Image, ImageDraw

# ---------- Maze Solver Classes ---------- #
class Node:
    def __init__(self, state, parent, action):
        self.state = state
        self.parent = parent
        self.action = action

class StackFrontier:
    def __init__(self):
        self.frontier = []

    def add(self, node):
        self.frontier.append(node)

    def contains_state(self, state):
        return any(node.state == state for node in self.frontier)

    def empty(self):
        return len(self.frontier) == 0

    def remove(self):
        if self.empty():
            raise Exception("empty frontier")
        return self.frontier.pop()

class Maze:
    def __init__(self, contents):
        if contents.count("A") != 1 or contents.count("B") != 1:
            raise Exception("Maze must contain exactly one start point (A) and one goal (B).")

        contents = contents.splitlines()
        self.height = len(contents)
        self.width = max(len(line) for line in contents)

        self.walls = []
        for i in range(self.height):
            row = []
            for j in range(self.width):
                try:
                    char = contents[i][j]
                    if char == "A":
                        self.start = (i, j)
                        row.append(False)
                    elif char == "B":
                        self.goal = (i, j)
                        row.append(False)
                    elif char == " ":
                        row.append(False)
                    else:
                        row.append(True)
                except IndexError:
                    row.append(False)
            self.walls.append(row)
        self.solution = None
        self.explored = set()

    def neighbors(self, state):
        row, col = state
        candidates = [
            ("up", (row - 1, col)),
            ("down", (row + 1, col)),
            ("left", (row, col - 1)),
            ("right", (row, col + 1))
        ]
        result = []
        for action, (r, c) in candidates:
            if 0 <= r < self.height and 0 <= c < self.width and not self.walls[r][c]:
                result.append((action, (r, c)))
        return result

    def solve(self):
        self.num_explored = 0
        start = Node(state=self.start, parent=None, action=None)
        frontier = StackFrontier()
        frontier.add(start)
        self.explored = set()

        while True:
            if frontier.empty():
                raise Exception("No solution found.")

            node = frontier.remove()
            self.num_explored += 1

            if node.state == self.goal:
                actions = []
                cells = []
                while node.parent is not None:
                    actions.append(node.action)
                    cells.append(node.state)
                    node = node.parent
                actions.reverse()
                cells.reverse()
                self.solution = (actions, cells)
                return

            self.explored.add(node.state)
            for action, state in self.neighbors(node.state):
                if not frontier.contains_state(state) and state not in self.explored:
                    child = Node(state=state, parent=node, action=action)
                    frontier.add(child)

    def draw_ascii(self):
        output = ""
        solution_cells = self.solution[1] if self.solution else None
        for i, row in enumerate(self.walls):
            for j, col in enumerate(row):
                if col:
                    output += "█"
                elif (i, j) == self.start:
                    output += "A"
                elif (i, j) == self.goal:
                    output += "B"
                elif solution_cells and (i, j) in solution_cells:
                    output += "*"
                else:
                    output += " "
            output += "\n"
        return output

    def output_image(self, filename="maze.png", show_solution=True, show_explored=True):
        cell_size = 40
        cell_border = 2
        img = Image.new("RGBA", (self.width * cell_size, self.height * cell_size), "black")
        draw = ImageDraw.Draw(img)

        solution = self.solution[1] if self.solution else None

        for i, row in enumerate(self.walls):
            for j, col in enumerate(row):
                if col:
                    fill = (40, 40, 40)
                elif (i, j) == self.start:
                    fill = (255, 0, 0)
                elif (i, j) == self.goal:
                    fill = (0, 171, 28)
                elif show_solution and solution and (i, j) in solution:
                    fill = (220, 235, 113)
                elif show_explored and (i, j) in self.explored:
                    fill = (212, 97, 85)
                else:
                    fill = (237, 240, 252)

                draw.rectangle(
                    [
                        (j * cell_size + cell_border, i * cell_size + cell_border),
                        ((j + 1) * cell_size - cell_border, (i + 1) * cell_size - cell_border)
                    ],
                    fill=fill
                )

        img.save(filename)

# ---------- GUI ---------- #
class MazeApp(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("Maze Solver")
        self.geometry("800x600")
        self.resizable(False, False)

        self.textbox = ctk.CTkTextbox(self, width=750, height=400, font=("Consolas", 14))
        self.textbox.pack(pady=20)

        self.upload_btn = ctk.CTkButton(self, text="Upload Maze File", command=self.upload_file)
        self.upload_btn.pack(pady=5)

        self.solve_btn = ctk.CTkButton(self, text="Solve Maze", command=self.solve_maze)
        self.solve_btn.pack(pady=5)

        self.status = ctk.CTkLabel(self, text="", text_color="green")
        self.status.pack(pady=10)

        self.contents = None
        self.maze = None

    def upload_file(self):
        path = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt")])
        if not path:
            return

        with open(path, "r") as file:
            self.contents = file.read()

        self.textbox.delete("1.0", "end")
        self.textbox.insert("end", self.contents)
        self.status.configure(text="Maze loaded. Click 'Solve Maze'.")

    def solve_maze(self):
        if not self.contents:
            messagebox.showerror("Error", "Please upload a maze file first.")
            return

        try:
            self.maze = Maze(self.contents)
            self.maze.solve()
            solved_text = self.maze.draw_ascii()
            self.maze.output_image("maze.png", show_explored=True)
            self.textbox.delete("1.0", "end")
            self.textbox.insert("end", solved_text)
            self.status.configure(text=f"Solved! States explored: {self.maze.num_explored}. Image saved as maze.png.")
        except Exception as e:
            messagebox.showerror("Maze Error", str(e))


if __name__ == "__main__":
    ctk.set_appearance_mode("System")
    app = MazeApp()
    app.mainloop()
