# ✏️ Crossword Puzzle Generator

A Python-based GUI application that generates crossword puzzles from a predefined grid structure and a list of words. Users can input their own grid design and custom word list to create personalized crossword puzzles.

---

## 🧩 Features

- Load custom **grid structure** (with `#` for blocked cells and `_` for open spaces)
- Import a list of **words** to populate the crossword
- Interactive **GUI interface** to visualize and generate the puzzle
- Highlighted word numbering on the grid
- Support for clearing canvas and starting fresh
- Data and assets managed via external `.zip` files

---

## 🖥️ Screenshot

<img width="1351" height="908" alt="image" src="https://github.com/user-attachments/assets/902edf71-4b10-493f-84f5-703b7b4d5142" />

---

## 🗂️ Project Structure
crossword-/
- crosswordAi.py # Main Python script (contains GUI + logic)
- assets.zip # Contains images, fonts or other UI resources
- data.zip # Sample structure and word input files
- README.md # This file

---

## 🔧 Requirements

- Python 3.x
- `tkinter` (for GUI)
- `os`, `zipfile`, and standard libraries

> No need to install external libraries — everything runs using built-in Python packages.

---

## 🚀 How to Run

1. Clone the repository:
   ```bash
   git clone https://github.com/anushkarao12/crossword-.git
   cd crossword-
   ```
2. Unzip the assets.zip and data.zip files into the working directory (if needed).

3. Run the application:
python crosswordAi.py

4. In the GUI:

Enter structure using # for blocked cells and _ for empty cells.
Provide a word list (one word per line).
Click "Generate Crossword" to build the puzzle.

---

## 📌 Example Input

Structure:

#_#

_#_

#_#_

#____

Words:

one

two

three

four

five

six

seven

eight

---

## 💡 Use Cases

Educational games and word practice
Custom crossword design for print
Word puzzles for students or kids
