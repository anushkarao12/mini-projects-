import pygame
import sys
import time
import math

# Constants
X = "X"
O = "O"
EMPTY = None

def initial_state():
    return [[EMPTY, EMPTY, EMPTY], [EMPTY, EMPTY, EMPTY], [EMPTY, EMPTY, EMPTY]]

def player(board):
    moves_made = sum(cell != EMPTY for row in board for cell in row)
    return X if moves_made % 2 == 0 else O

def actions(board):
    return {(i, j) for i in range(3) for j in range(3) if board[i][j] == EMPTY}

def result(board, action):
    i, j = action
    new_board = [row[:] for row in board]
    new_board[i][j] = player(board)
    return new_board

def winner(board):
    for i in range(3):
        if board[i][0] == board[i][1] == board[i][2] != EMPTY:
            return board[i][0]
        if board[0][i] == board[1][i] == board[2][i] != EMPTY:
            return board[0][i]
    if board[0][0] == board[1][1] == board[2][2] != EMPTY:
        return board[0][0]
    if board[0][2] == board[1][1] == board[2][0] != EMPTY:
        return board[0][2]
    return None

def terminal(board):
    return winner(board) is not None or all(cell != EMPTY for row in board for cell in row)

def utility(board):
    w = winner(board)
    return 1 if w == X else -1 if w == O else 0

def minimax(board):
    if terminal(board):
        return None
    current = player(board)
    best_action = None
    best_score = -math.inf if current == X else math.inf
    for action in actions(board):
        new_board = result(board, action)
        score = minimax_score(new_board, current)
        if current == X and score > best_score:
            best_score, best_action = score, action
        elif current == O and score < best_score:
            best_score, best_action = score, action
    return best_action

def minimax_score(board, current):
    if terminal(board):
        return utility(board)
    if current == X:
        return max(minimax_score(result(board, a), O) for a in actions(board))
    else:
        return min(minimax_score(result(board, a), X) for a in actions(board))

# Pygame Setup
pygame.init()
size = width, height = 600, 400
screen = pygame.display.set_mode(size)
pygame.display.set_caption("Tic Tac Toe AI")

black = (0, 0, 0)
white = (255, 255, 255)

# Font
try:
    mediumFont = pygame.font.Font("OpenSans-Regular.ttf", 28)
    largeFont = pygame.font.Font("OpenSans-Regular.ttf", 40)
    moveFont = pygame.font.Font("OpenSans-Regular.ttf", 60)
except:
    # Fallback font
    mediumFont = pygame.font.SysFont("Arial", 28)
    largeFont = pygame.font.SysFont("Arial", 40)
    moveFont = pygame.font.SysFont("Arial", 60)

user = None
board = initial_state()
ai_turn = False

while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()

    screen.fill(black)

    if user is None:
        title = largeFont.render("Play Tic-Tac-Toe", True, white)
        titleRect = title.get_rect(center=(width / 2, 50))
        screen.blit(title, titleRect)

        playXButton = pygame.Rect((width / 8), (height / 2), width / 4, 50)
        playOButton = pygame.Rect(5 * (width / 8), (height / 2), width / 4, 50)

        playX = mediumFont.render("Play as X", True, black)
        playO = mediumFont.render("Play as O", True, black)

        pygame.draw.rect(screen, white, playXButton)
        pygame.draw.rect(screen, white, playOButton)

        screen.blit(playX, playX.get_rect(center=playXButton.center))
        screen.blit(playO, playO.get_rect(center=playOButton.center))

        click, _, _ = pygame.mouse.get_pressed()
        if click == 1:
            mouse = pygame.mouse.get_pos()
            if playXButton.collidepoint(mouse):
                time.sleep(0.2)
                user = X
            elif playOButton.collidepoint(mouse):
                time.sleep(0.2)
                user = O
    else:
        tile_size = 80
        origin = (width / 2 - 1.5 * tile_size, height / 2 - 1.5 * tile_size)
        tiles = []

        for i in range(3):
            row = []
            for j in range(3):
                rect = pygame.Rect(origin[0] + j * tile_size, origin[1] + i * tile_size, tile_size, tile_size)
                pygame.draw.rect(screen, white, rect, 3)
                if board[i][j] != EMPTY:
                    move = moveFont.render(board[i][j], True, white)
                    screen.blit(move, move.get_rect(center=rect.center))
                row.append(rect)
            tiles.append(row)

        game_over = terminal(board)
        turn = player(board)

        if game_over:
            title_text = "Game Over: Tie." if winner(board) is None else f"Game Over: {winner(board)} wins."
        else:
            title_text = f"Play as {user}" if user == turn else "Computer thinking..."

        title = largeFont.render(title_text, True, white)
        screen.blit(title, title.get_rect(center=(width / 2, 30)))

        if not game_over and user != turn:
            if ai_turn:
                time.sleep(0.5)
                board = result(board, minimax(board))
                ai_turn = False
            else:
                ai_turn = True

        if not game_over and user == turn:
            click, _, _ = pygame.mouse.get_pressed()
            if click == 1:
                mouse = pygame.mouse.get_pos()
                for i in range(3):
                    for j in range(3):
                        if board[i][j] == EMPTY and tiles[i][j].collidepoint(mouse):
                            board = result(board, (i, j))

        if game_over:
            againButton = pygame.Rect(width / 3, height - 65, width / 3, 50)
            again = mediumFont.render("Play Again", True, black)
            pygame.draw.rect(screen, white, againButton)
            screen.blit(again, again.get_rect(center=againButton.center))

            click, _, _ = pygame.mouse.get_pressed()
            if click == 1 and againButton.collidepoint(pygame.mouse.get_pos()):
                time.sleep(0.2)
                board = initial_state()
                user = None
                ai_turn = False

    pygame.display.flip()
