# 📊 PageRank

This project implements the [PageRank](https://en.wikipedia.org/wiki/PageRank) algorithm, originally developed by Google, to rank web pages based on the structure of their links. It includes two approaches:

- **Sampling-based PageRank**
- **Iterative PageRank**

The code is written in Python and includes a simple **Tkinter-based GUI** for user-friendly interaction.

---

## 📁 Project Structure

Pagerank/

- pagerank.py # Main script containing the logic and GUI
- corpus0.zip # Sample corpus with HTML files (linked pages)
- corpus1.zip # Another sample corpus
- corpus2.zip # Another sample corpus
- README.md # Project description

---

## 🧠 How It Works

- Parses `.html` files to create a corpus of interlinked pages.
- Computes PageRank using:
  - **Sampling**: Random walks through the web graph.
  - **Iteration**: Updates rank values until convergence.

---

## 🔧 Requirements

- Python 3.x
- No external libraries needed (only `tkinter` which comes with Python)

---

## 🖥️ Running the Program

1. **Unzip one of the corpus files** (`corpus0.zip`, `corpus1.zip`, etc.) into a folder.
2. Run the script:

```bash
python pagerank.py
```
3. A GUI window will open. Click “Select Folder and Run” and choose the unzipped corpus folder.
4. The program will display PageRank results using both methods.

---

## 📷 GUI Preview

The GUI allows you to choose a corpus directory and automatically displays PageRank results using sampling and iteration methods.

<img width="767" height="569" alt="image" src="https://github.com/user-attachments/assets/a8a4aaa4-ab46-434a-a987-75735e4463a4" />
<img width="1048" height="603" alt="image" src="https://github.com/user-attachments/assets/f8f84d2d-5cba-45b9-82a2-f4a29f06a00d" />
<img width="794" height="575" alt="image" src="https://github.com/user-attachments/assets/a5a7d060-5436-4bd5-9ae4-e226000f02cb" />


---

## 📚 Sample Output

📊 PageRank Results from Sampling (n = 10000)
  1.html: 0.2214
  2.html: 0.3045
  3.html: 0.4741

📊 PageRank Results from Iteration
  1.html: 0.2221
  2.html: 0.3029
  3.html: 0.4750

---

## 📜 License

This project is for educational purposes. Feel free to use and modify it for learning or personal projects.

---

## ✅ TODO (Optional Enhancements)

- Add graph visualization using networkx
- Show link structure visually
- Add command-line arguments for damping/samples
- Improve the GUI with progress indicators

