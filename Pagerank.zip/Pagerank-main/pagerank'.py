import os
import random
import re
import sys
import tkinter as tk
from tkinter import filedialog, messagebox, scrolledtext

DAMPING = 0.85
SAMPLES = 10000


def crawl(directory):
    pages = dict()
    for filename in os.listdir(directory):
        if not filename.endswith(".html"):
            continue
        with open(os.path.join(directory, filename), encoding="utf-8") as f:
            contents = f.read()
            links = re.findall(r'<a\s+(?:[^>]*?)href="([^"]*)"', contents)
            pages[filename] = set(links) - {filename}
    for filename in pages:
        pages[filename] = set(link for link in pages[filename] if link in pages)
    return pages


def transition_model(corpus, page, damping_factor):
    links = corpus[page]
    num_links = len(links)
    transition_probs = {}
    if num_links == 0:
        # Random jump to any page
        return {p: 1 / len(corpus) for p in corpus}
    for link in links:
        transition_probs[link] = damping_factor / num_links
    for page in corpus:
        transition_probs[page] = transition_probs.get(page, 0) + (1 - damping_factor) / len(corpus)
    return transition_probs


def sample_pagerank(corpus, damping_factor, n):
    page_ranks = {page: 0 for page in corpus}
    current_page = random.choice(list(corpus.keys()))
    for _ in range(n):
        transition_probs = transition_model(corpus, current_page, damping_factor)
        current_page = random.choices(list(transition_probs.keys()), weights=transition_probs.values())[0]
        page_ranks[current_page] += 1
    for page in page_ranks:
        page_ranks[page] /= n
    return page_ranks


def iterate_pagerank(corpus, damping_factor):
    page_ranks = {page: 1 / len(corpus) for page in corpus}
    while True:
        new_page_ranks = {}
        for page in corpus:
            total = 0
            for other in corpus:
                if page in corpus[other]:
                    total += page_ranks[other] / len(corpus[other])
                elif not corpus[other]:
                    total += page_ranks[other] / len(corpus)
            new_rank = (1 - damping_factor) / len(corpus) + damping_factor * total
            new_page_ranks[page] = new_rank
        if all(abs(new_page_ranks[page] - page_ranks[page]) < 1e-8 for page in corpus):
            break
        page_ranks = new_page_ranks
    return page_ranks


# GUI Code
def run_pagerank():
    folder = filedialog.askdirectory()
    if not folder:
        return

    try:
        corpus = crawl(folder)
        if not corpus:
            messagebox.showerror("Error", "No valid HTML files found in the folder.")
            return

        sample_ranks = sample_pagerank(corpus, DAMPING, SAMPLES)
        iter_ranks = iterate_pagerank(corpus, DAMPING)

        result_text = f"📊 PageRank Results from Sampling (n = {SAMPLES})\n"
        for page in sorted(sample_ranks):
            result_text += f"  {page}: {sample_ranks[page]:.4f}\n"

        result_text += "\n📊 PageRank Results from Iteration\n"
        for page in sorted(iter_ranks):
            result_text += f"  {page}: {iter_ranks[page]:.4f}\n"

        output_text.delete("1.0", tk.END)
        output_text.insert(tk.END, result_text)

    except Exception as e:
        messagebox.showerror("Error", str(e))


# Setup tkinter window
root = tk.Tk()
root.title("PageRank GUI")
root.geometry("700x500")
root.configure(bg="#f0f0f0")

title_label = tk.Label(root, text="PageRank Calculator", font=("Helvetica", 16, "bold"), bg="#f0f0f0")
title_label.pack(pady=10)

desc_label = tk.Label(root, text="Select a folder containing HTML pages to compute PageRank.", bg="#f0f0f0")
desc_label.pack()

select_button = tk.Button(root, text="📂 Select Folder and Run", command=run_pagerank, bg="#4CAF50", fg="white", font=("Helvetica", 12))
select_button.pack(pady=10)

output_text = scrolledtext.ScrolledText(root, wrap=tk.WORD, width=80, height=20, font=("Courier New", 10))
output_text.pack(pady=10)

root.mainloop()
