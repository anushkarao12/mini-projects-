# Heredity

This project simulates genetic inheritance to estimate the probability that a person has a particular gene and exhibits a trait, based on information about their family.

## 🧬 Overview

Given a family tree and genetic data in CSV format, the program calculates:

* The probability of each person having 0, 1, or 2 copies of a particular gene.
* The probability of each person exhibiting a trait based on their gene count.

It does this by modeling all possible gene and trait combinations for the individuals and using joint probability distributions.

## 📁 Files

* `heredity.py` — Main Python script to compute inheritance probabilities.
* `family0.csv`, `family1.csv`, `family2.csv` — Sample datasets containing family information (names, parents, and known trait).
* `README.md` — Project documentation.

## 🧾 CSV Format

Each CSV contains rows like:

```
name,mother,father,trait
Harry,,,""
James,,,"True"
Lily,,,"False"
```

* `"trait"` can be `True`, `False`, or blank (unknown).
* `"mother"` and `"father"` refer to names of other individuals in the CSV.

## 🚀 How to Run

To run the script on a dataset:

```bash
python heredity.py family0.csv
```

The output will be the calculated probabilities for each individual in the family.

## 🧠 Concepts Used

* Probability theory
* Genetic inheritance modeling
* Joint probability calculation
* Bayes’ theorem (implicitly through conditional probabilities)

## 📌 Example Output

```
Harry:
  Gene:
    2: 0.0100
    1: 0.0030
    0: 0.9870
  Trait:
    True: 0.0021
    False: 0.9979
```

## 🔧 Requirements

* Python 3.x
* Tkinter library needed

## 📝 Credits

Created as part of a CS/AI problem set exploring probabilistic models and genetic inheritance.

